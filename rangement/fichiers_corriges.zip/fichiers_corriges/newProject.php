<?php
/*

Localisation : 
But : premiere ouverture d'un projet
 */
 
include('taskFonctions.php'); 
echo "<h1> $project </h1>"; 

/* ----------------------------------------
 affichage des biobricks initiales du projet  
 ------------------------------------------- */

$allNames=array();
$bNb=count($names);
echo "<section class='level'>";

$id = 0;
for($i=0;$i<$bNb;$i++){
  $id++;
  $name=$names[$i];
  $newTask=new task($name,'','',$names,-1);
  array_push($allNames,$name); 
  $name='./Images/'.$name.'.png';
    echo"<div class='biobrick' ondrop='drop(event)' ondragover='allowDrop(event)'><img src=$name id=$id draggable='true' ondragstart='drag(event)'></div>";
}
echo "</section>";

foreach($names as $name){
  $taskNames[]=$name; 
}

$idTask=$id+100;
$idButton=$id+50;

echo"<div id='level'>
         <div class='task' style='width:180px' id=$idTask ondrop='drop(event)' ondragover='allowDrop(event)'></div>
     </div>
<form name='button' method='POST' action=''>
<button type='button' id=$idButton onclick='addTask(this.id);'>Nouvelle tâche</button>
<div></div>
<button type='button'  onclick='addLevel();'>Nouveau niveau</button>
<input type='hidden' name='save1' id='save1' value='' />
<input type='hidden' name='save2' id='save2' value='' />
</form>";

echo"</div>"; 

echo"<div class='details' id='details'>
         <form name='selectedState' method='POST' action='' >
             <input type='hidden' name='save' id='save' value='' />
                 <label for='state'>Etat de la tâche : </label></br>

                 <input type='radio' id='in' name='state' value='in'";
                 if(isset($_POST['state'])&& $_POST['state']=='in')echo "checked"; echo "/> En cours

                 <input type='radio' id='done' name='state' value='done'";
                 if(isset($_POST['state'])&& $_POST['state']=='done')echo "checked"; echo "/> Terminé

            <input type='button' name='stateValidate' value='Valider' onclick='changeState();'/>
        </form>
        <form method='POST' action=''><input type='button' name='pop_up' value='Fermer' onclick=''/>
        </form>
    </div>"; 
?>

