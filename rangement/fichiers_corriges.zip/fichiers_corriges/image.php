<?php
$name1=&$_POST['img1'];
$name2=&$_POST['img2'];

if($name1!='' and $name2!=''){
  $name1=str_replace('.png','',$name1);
  $name2=str_replace('.png','',$name2);
  $nbParent=count(explode('_',$name1))+count(explode('_',$name2));
  $name='./Images/'.$name1.'_'.$name2.'.png';
  $image1 = imagecreatefrompng('./Images/'.$name1.'.png');
  $image = imagecreate(74*$nbParent,20);
  imagecopymerge($image,$image1,0,0,0,0,imagesx($image1),20,100); 
  $image2 = imagecreatefrompng('./Images/'.$name2.'.png');
  imagecopymerge($image,$image2,imagesx($image1),0,0,0,imagesx($image2),20,100);  imagepng($image,$name);
echo $name;
}
?>
    