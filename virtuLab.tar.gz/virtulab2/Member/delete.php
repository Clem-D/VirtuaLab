<?php

echo " <p> Your count was deleted ! See you ! <br> <a href=\"../index.php\"> back to the main page. </a> </p> ";

?>
