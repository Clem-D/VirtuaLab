<?php


$title="Timeout";
$rubric="NoMenu";
// include('header.php');  uncomment it and it will bug :)
echo"<section> <p> Your session has expired, please go to the <a href=\"../rubrics/home.php\" >Home Menu </a> for refresh it.</p> </section>";

//include("footer.php");
?>
