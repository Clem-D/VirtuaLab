<?php
?>

<html>
<head>
<title>Vid&eacute;o</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>
 
<body>
        <iframe width="860" height="540" src="http://www.youtube.com/embed/Sjeo1hK1I-E?feature=player_detailpage;vq=hd720" frameborder="0" allowfullscreen></iframe>
</body>
</html>