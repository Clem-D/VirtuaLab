<?php
$dureelimite=60; // one minute
?>
